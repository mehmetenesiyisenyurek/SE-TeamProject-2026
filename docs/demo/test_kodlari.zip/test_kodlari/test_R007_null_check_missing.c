int main() {
    int *ptr = malloc(4);

    *ptr;

    return 0;
}
