int main() {
    int *ptr;

    *ptr;

    return 0;
}
