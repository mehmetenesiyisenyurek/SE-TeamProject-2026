int main() {
    int *ptr = malloc(4);

    if (ptr == NULL) {
        return 1;
    }

    free(ptr);
    *ptr;

    return 0;
}
