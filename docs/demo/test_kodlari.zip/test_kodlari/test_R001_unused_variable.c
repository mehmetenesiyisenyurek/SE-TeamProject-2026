int main() {
    int kullanilan = 10;
    int kullanilmayan = 20;

    kullanilan = kullanilan + 1;

    return 0;
}
